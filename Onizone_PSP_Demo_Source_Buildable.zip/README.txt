
Onizone – PSP Demo (Homebrew)
=============================
Status: Source code + Makefile (build with PSPSDK)
Output: EBOOT.PBP  (run on PPSSPP or real PSP via PSP/GAME/ONIZONE/)

Features in this demo
---------------------
- TH/EN language toggle (Press [] Square)
- Move with D-Pad
- Run with Cross (X) — disabled if Hunger < 30
- Hunger decreases over time; Triangle (Δ) = Eat (+40 Hunger) if you have food
- Start with some money; Circle (O) = Buy skateboard (speed boost, ignores hunger limit)
- Skateboard toggles sprint even when hungry
- Simple HUD text (fps, money, hunger, language, speed)

Build (Linux/Mac with PSPSDK installed)
---------------------------------------
1) Install PSPSDK (psptoolchain). See: https://github.com/pspdev/psptoolchain
   Make sure env vars are set, e.g.:
      export PSPDEV=/usr/local/pspdev
      export PATH=$PATH:$PSPDEV/bin
2) In this folder, run:
      make
   You should get: EBOOT.PBP in ./

Run on PPSSPP
-------------
- Open PPSSPP → Load "EBOOT.PBP"

Run on real PSP
---------------
- Create folder on Memory Stick:
    /PSP/GAME/ONIZONE/
- Copy EBOOT.PBP into that folder.
- On PSP, go to Game → Memory Stick → Onizone PSP Demo

Controls
--------
- D-Pad  : Move
- X      : Run (if Hunger >= 30 or you own a skateboard)
- []     : Toggle TH/EN
- O      : Buy skateboard (-200 G)  [once]
- Δ      : Eat food if available (+40 Hunger, consumes 1 food)
- Start  : Exit demo

Notes
-----
- This is a text HUD demo (no textures) to ensure small size and maximum compatibility.
- From here you can add GU rendering, sprites, audio (AT3), and maps as needed.


== Quick Build ==
Linux/Mac: ./build_linux_mac.sh
Windows (MSYS2): build_windows_msys2.cmd
Android (Termux): ./build_termux_android.sh
GitHub Actions: push repo then download artifact
