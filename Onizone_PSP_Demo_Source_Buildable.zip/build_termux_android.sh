#!/data/data/com.termux/files/usr/bin/bash
set -e
pkg update -y && pkg install -y git clang make python
# Install psptoolchain (takes a long time)
git clone https://github.com/pspdev/psptoolchain.git
cd psptoolchain
./bootstrap && ./build-all.sh
echo 'export PSPDEV=$HOME/pspdev' >> $HOME/.bashrc
echo 'export PATH=$PATH:$PSPDEV/bin' >> $HOME/.bashrc
source $HOME/.bashrc
cd ..
# Build project
make -C "$(dirname "$0")" clean || true
make -C "$(dirname "$0")"
echo "Build done → EBOOT.PBP"
