
#include <pspkernel.h>
#include <pspdebug.h>
#include <pspdisplay.h>
#include <pspctrl.h>
#include <psprtc.h>
#include <stdio.h>
#include <string.h>

PSP_MODULE_INFO("Onizone PSP Demo", 0, 1, 0);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER);

#define printf pspDebugScreenPrintf

typedef enum { LANG_TH = 0, LANG_EN = 1 } Language;

typedef struct {
    float x, y;
    float speedWalk;
    float speedRun;
    int hasSkate;
    int hunger;     // 0-100
    int food;       // item count
    int money;      // G
} Player;

static Language gLang = LANG_TH;
static Player player;
static unsigned int prevButtons = 0;

// time
static u64 tick_last = 0;
static float dt = 0.0f;

int running = 1;

// Utils
int pressed(unsigned int buttons, unsigned int mask){
    return ((buttons & mask) && !(prevButtons & mask));
}

void drawHUD(float fps){
    pspDebugScreenSetXY(0,0);
    if(gLang == LANG_TH){
        printf("Onizone PSP Demo  | FPS: %.1f\n", fps);
        printf("ภาษา: ไทย (กด [] เพื่อสลับ) | Start = ออกเกม\n");
        printf("เงิน: %d G  | ความหิว: %d/100  | อาหาร: %d\n", player.money, player.hunger, player.food);
        printf("สเก็ตบอร์ด: %s  | ความเร็ว: เดิน %.1f / วิ่ง %.1f\n", player.hasSkate ? "มี" : "ไม่มี", player.speedWalk, player.speedRun);
        printf("ควบคุม: ลูกศร = เดิน, X = วิ่ง, O = ซื้อสเก็ต (200G), Δ = กิน (+40)\n");
    }else{
        printf("Onizone PSP Demo  | FPS: %.1f\n", fps);
        printf("Lang: EN (press [] to toggle) | Start = Exit\n");
        printf("Money: %d G  | Hunger: %d/100  | Food: %d\n", player.money, player.hunger, player.food);
        printf("Skateboard: %s  | Speed: Walk %.1f / Run %.1f\n", player.hasSkate ? "YES" : "NO", player.speedWalk, player.speedRun);
        printf("Controls: D-Pad=Move, X=Run, O=Buy Skate (200G), Δ=Eat (+40)\n");
    }
    // position
    printf("\nPos: (%.1f, %.1f)\n", player.x, player.y);
}

int exit_callback(int arg1, int arg2, void *common) {
    running = 0;
    return 0;
}

int CallbackThread(SceSize args, void *argp) {
    int cbid = sceKernelCreateCallback("Exit Callback", exit_callback, NULL);
    sceKernelRegisterExitCallback(cbid);
    sceKernelSleepThreadCB();
    return 0;
}

int SetupCallbacks(void) {
    int thid = 0;
    thid = sceKernelCreateThread("update_thread", CallbackThread, 0x11, 0xFA0, 0, 0);
    if(thid >= 0) sceKernelStartThread(thid, 0, 0);
    return thid;
}

int main(int argc, char *argv[]){
    pspDebugScreenInit();
    SetupCallbacks();

    // init player
    player.x = 240; player.y = 136;
    player.speedWalk = 1.5f;
    player.speedRun  = 3.0f;
    player.hasSkate = 0;
    player.hunger = 100;
    player.food = 2;
    player.money = 300;

    SceCtrlData pad;
    sceCtrlSetSamplingCycle(0);
    sceCtrlSetSamplingMode(PSP_CTRL_MODE_DIGITAL);

    // timebase
    tick_last = sceKernelGetSystemTimeWide();

    while(running){
        // dt
        u64 tick_now = sceKernelGetSystemTimeWide();
        u64 diff = tick_now - tick_last;
        tick_last = tick_now;
        dt = (float)diff / 1000000.0f; // seconds

        // Read input
        sceCtrlReadBufferPositive(&pad, 1);
        unsigned int buttons = pad.Buttons;

        // language toggle
        if(pressed(buttons, PSP_CTRL_SQUARE)){
            gLang = (gLang == LANG_TH) ? LANG_EN : LANG_TH;
        }

        // buy skateboard
        if(pressed(buttons, PSP_CTRL_CIRCLE)){
            if(!player.hasSkate && player.money >= 200){
                player.money -= 200;
                player.hasSkate = 1;
            }
        }

        // eat
        if(pressed(buttons, PSP_CTRL_TRIANGLE)){
            if(player.food > 0){
                player.food -= 1;
                player.hunger += 40;
                if(player.hunger > 100) player.hunger = 100;
            }
        }

        // movement
        float speed = player.speedWalk;
        int canRun = (player.hunger >= 30) || player.hasSkate;
        if((buttons & PSP_CTRL_CROSS) && canRun){
            speed = player.speedRun * (player.hasSkate ? 1.8f : 1.0f);
        }

        if(buttons & PSP_CTRL_UP)    player.y -= speed;
        if(buttons & PSP_CTRL_DOWN)  player.y += speed;
        if(buttons & PSP_CTRL_LEFT)  player.x -= speed;
        if(buttons & PSP_CTRL_RIGHT) player.x += speed;

        // hunger drain
        static float hungerTimer = 0.0f;
        hungerTimer += dt;
        if(hungerTimer >= 1.0f){ // every 1 sec = -1 hunger
            hungerTimer = 0.0f;
            if(player.hunger > 0) player.hunger -= 1;
        }

        // clamp pos
        if(player.x < 0) player.x = 0; if(player.x > 480) player.x = 480;
        if(player.y < 0) player.y = 0; if(player.y > 272) player.y = 272;

        // draw
        pspDebugScreenClear();
        float fps = (dt > 0.0f) ? (1.0f/dt) : 0.0f;
        drawHUD(fps);

        prevButtons = buttons;

        // small delay to reduce CPU
        sceKernelDelayThread(5000); // 5 ms
    }

    sceKernelExitGame();
    return 0;
}
