#!/usr/bin/env bash
set -e
if [ -z "$PSPDEV" ]; then
  echo "PSPDEV not set. Please install psptoolchain and export PSPDEV=/usr/local/pspdev"
  exit 1
fi
export PATH="$PATH:$PSPDEV/bin"
make clean || true
make -j$(getconf _NPROCESSORS_ONLN 2>/dev/null || echo 2)
echo "Build done → EBOOT.PBP"
